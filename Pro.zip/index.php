<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
         <?php $n=$_GET["n"]; ?>
    
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/>
    <title>Merry Happy New Year Greetings with Name</title>
    <meta name="google" value="notranslate">
    <meta property="og:type" content="Greetings" />
    <meta property="og:title" content="Happy New Year Greetings with Name" />
    <meta property="og:url" content="http://www.www.techripon.com/2019">
    <meta property="og:description" content="Happy New Year 2019 - Sent Animated & beautiful Happy New Year greeting card with your name to friends & relatives" />
    <meta property="og:site_name" content="Site" />
    <meta property="og:image" content="img/gift.webp" />
    <meta property="og:image:secure_url" content="img/gift.webp" />
    <meta property="og:image:width" content="993" />
    <meta property="og:image:height" content="559" />
    <meta property="og:image:alt" content="Merry Happy New Year Greetings with Name" />
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <link href='https://fonts.googleapis.com/css?family=Sofia:&effect=neon' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="icon" type="image/png" sizes="32x32" href="img/wp.webp">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script>
 if ('serviceWorker' in navigator) {

    console.log("Will the service worker register?");

    navigator.serviceWorker.register('service-worker.js')
      .then(function(reg){

        console.log("Yes, it did.");

     }).catch(function(err) {

        console.log("No it didn't. This happened:", err)

    });
 }


</script>

</head>
<iframe width="0" height="0" src="song.mp3" frameborder="0" allowfullscreen></iframe>
<body class="bg" id="rakhi" style="background-image: linear-gradient(to bottom, #ff0000, #ff517f, #ff97d2, #f8d1fc, #ffffff););
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;">

<center><img src="https://i.postimg.cc/RCfyQr4R/hh.png" width="100%" height="12%" alt="A very merry Christmas and happy new year 2019"></center>
<div class="w3-bar">
  <button class="w3-bar-item w3-button w3-black" style="width:33.3%"><a href="pages/about.php">About</a></button>
  <button class="w3-bar-item w3-button w3-teal" style="width:33.3%"><a href="www.www.techripon.com/2019">Home</a></button>
  <button class="w3-bar-item w3-button w3-blue" style="width:33.3%"><a href="pages/tos.php">TOS</a></button>
</div>
<center>
<!---------Adsense Link Ads-------->

</center>
<div class="container">
  <marquee class="m1" behavior="scroll" direction="up" scrolldelay="5">  <br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>

</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="5"><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
</marquee>
<script src="js/doodle.js"></script> 
<script type="text/javascript">
 doodle.init("img/fly.webp");
</script>
<div class="container" >
    <div class="main-greeting" >
<div align="center html2canvas-ignore">
     <div style="font-size: 17px; font-weight: 800; color: white;" >
<center>
    <p id="demo"></p></center>

            <div class="main_body" >
      <center>
<figure>
    
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>


</figure><br> <br><br><br>
</center>
<p id="demo"></p> 
<center>
<img src="https://i.imgur.com/DPMaeP8.png" width="70%" height="13%"style="animation: tada 4s infinite"><br>
<img src="https://i.postimg.cc/BvN39wmT/h.png" width="80%" style="animation: pulse 1.5s infinite"><br><br>
</center>

<center>
<img src="img/1.jpg" class="img-responsive" alt="RipoN" width="90%">
<img src="img/2.jpg" class="img-responsive" alt="RipoN" width="90%">
<img src="img/5.jpg" class="img-responsive" alt="RipoN" width="90%">
<img src="img/3.jpg" class="img-responsive" alt="RipoN" width="90%">
<img src="img/4.jpg" class="img-responsive" alt="RipoN" width="90%">

</center>


<center>
<p class="hny-txt">
  <span style="font-size: 32px;"><b>New Year Gift By</span> <span style="color: #008000;"></span></p></center>&nbsp;
<br>
<center>
   <!-- Display the countdown timer in an element -->


<script>
// Set the date we're counting down to
var countDownDate = new Date("jan 01, 2019 00:00:00").getTime();

// Update the count down every 01 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "<i> Days,</i> " + hours + " <i>Hrs,</i> "
  + minutes + "<i> Min,</i> " + seconds + "<i> Sec</i> ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Happy New Year 2019";
  }
}, 1000);
</script> 
</div>
<center>

<div class="button">
    
                
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</div></center><br>
<center>
<!---------Adsense Link Ads-------->

</center>
<center>
<div class="w3-bar">
  <button class="w3-bar-item w3-button w3-black" style="width:33.3%"><a href="pages/about.php">About</a></button>
  <button class="w3-bar-item w3-button w3-teal" style="width:33.3%"><a href="###">Home</a></button>
  <button class="w3-bar-item w3-button w3-red" style="width:33.3%"><a href="pages/tos.php">TOS</a></button>
</div>
</center>
<center>
<span style="font-size: 7pt; color: #000000;"><p>Is the No. one Festival Wishing site right now, here you can get many international Festival wishing Greeting card templates, which will help you to create an awesome looking Greeting card with your own name, what you will need to do? just Enter your name in the below box and Click on Go button, on the next page you will see your name billing on top, now just Click on the Share button to share the greetings with your Family, Friends, and relatives. Thank You!</p>
Copyrights © 2018 | All Rights Reserved Powered by <a href="https://www.ripon.in">RipoN</a>
</span>
</center>

<br><br>
</div>
</div>
</div>
</div>
</div>
<form method="get" action="share.php">
  <div class="enter-name">
    <input class="animated pulse infinite" type="name" required="" maxlength="50" name="n" placeholder="👉 Enter Your Name Here">
    <button class="btn animated shake infinite" type="submit"><span>👉</span> Go</button>
  </div>
</form>       
<canvas id="canvas" style="position : absolute; top : 0px; left : 0px;"></canvas>
    </body>
    <link rel="manifest" href="js/manifest.json">
</html> 

