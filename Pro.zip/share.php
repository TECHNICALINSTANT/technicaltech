<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
         <?php $n=$_GET["n"]; ?>
    
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/>
    <title>Share Happy New Year Greetings with Name on WhatsApp</title>
    <meta name="google" value="notranslate">
    <meta property="og:type" content="Greetings" />
    <meta property="og:title" content="Happy New Year Greetings with Name" />
    <meta property="og:url" content="http://www.techripon.com/2019/">
    <meta property="og:description" content="Share Happy New Year Greetings with Name on WhatsApp" />
    <meta property="og:site_name" content="###" />
    <meta property="og:image" content="img/gift.webp" />
    <meta property="og:image:secure_url" content="img/gift.webp" />
    <meta property="og:image:width" content="993" />
    <meta property="og:image:height" content="559" />
    <meta property="og:image:alt" content="Happy New Year Greetings with Name" />
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <link href='https://fonts.googleapis.com/css?family=Sofia:&effect=neon' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="icon" type="image/png" sizes="32x32" href="img/wp.webp">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        .footerbtn {
 
            display: block;
            line-height: 15px;
            position: fixed;
            left:0px;
            bottom:0px;
            height:40px;
            
border-radius: 15px;
  box-sizing: border-box;
  padding: 5px;
  background:#34af23;
  color: #ffffff;
  font-size: 18px;
  text-align: center;
  text-decoration: none;
  width:95%;
 margin-left:10px;
            margin-right:30px;
            box-shadow: 0 4px 12px 0 rgba(0, 0, 0, .3);
            animation: footer infinite linear 1s;
            -webkit-transform: translate3d(30%,0,0);
            transform: translate3d(30%,0,0);
            position: fixed;
           
}

.footerbtn :active {
            box-shadow: none
        }

        @-webkit-keyframes footer {
            from {
                -webkit-transform: rotateZ(0)
            }
            25% {
                -webkit-transform: rotateZ(1.5deg)
            }
            50% {
                -webkit-transform: rotateZ(0deg)
            }
            75% {
                -webkit-transform: rotateZ(-1.5deg)
            }
            to {
                -webkit-transform: rotateZ(0)
            }}
        
    </style>
    
</head>

<body class="bg" id="rakhi" style="background: linear-gradient(to bottom right, #ff0c45, #ffffff, #edff2d);
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;">
<center><img src="https://i.postimg.cc/RCfyQr4R/hh.png" width="100%" height="12%" alt="A very merry Christmas and happy new year 2019"></center>
<center>
<!---------Adsense Link Ads-------->

</center>
<div class="container">
  <marquee class="m1" behavior="scroll" direction="up" scrolldelay="5">  <br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>

</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="5"><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
<img src="https://goo.gl/sjadWz" height="119px" width="35px"/><br><br>
</marquee>
<div class="container" >
    <div class="main-greeting" >
<div align="center html2canvas-ignore">
     <div style="font-size: 17px; font-weight: 800; color: white;" >
<center>
    <p id="demo"></p></center>

            <div class="main_body" >
<center>
<figure>
    
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>
<h1 class="naming">                 
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</h1>


</figure><br> <br><br><br>
</center>
<p id="demo"></p> 
<center>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:&effect=outline' rel='stylesheet'>
<span class="font-effect-outline" style="font-size: 18pt; font-family: Open Sans; color: #edff2d;">
Now Share it to your friends on<br />
WhatsApp, Facebook, & Other Places<br />
So that People can see your Name and Wishes sent by You.<br />
</pre>
<br />
</center>
<center>
<img src="https://i.imgur.com/JCwLyHl.gif" width="350px" height="400px"style="animation: pulse 1.5s infinite">
</center>
  <br/><br>

   <!-- Display the countdown timer in an element -->
<script>
// Set the date we're counting down to
var countDownDate = new Date("Sep 13, 2018 00:00:00").getTime();

// Update the count down every 01 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "<i> Days,</i> " + hours + " <i>Hrs,</i> "
  + minutes + "<i> Min,</i> " + seconds + "<i> Sec</i> ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Merry Christmas";
  }
}, 1000);
</script> 
</div>

<center>
<div class="button">
    
                
<?php
if($n==null)

 echo "[Your Name]";
    else
    echo $_GET["n"];
?>
</div></center><br>

<center>
<!---------Adsense Link Ads-------->

</center>
<center>
<div class="w3-bar">
  <button class="w3-bar-item w3-button w3-black" style="width:33.3%"><a href="pages/about.php">About</a></button>
  <button class="w3-bar-item w3-button w3-teal" style="width:33.3%"><a href="index.php">Home</a></button>
  <button class="w3-bar-item w3-button w3-red" style="width:33.3%"><a href="pages/tos.php">TOS</a></button>
</div>
</center>
<center>
<span style="font-size: 7pt; color: #000000;"><p>Is the No. one Festival Wishing site right now, here you can get many international Festival wishing Greeting card templates, which will help you to create an awesome looking Greeting card with your own name, what you will need to do? just Enter your name in the below box and Click on Go button, on the next page you will see your name billing on top, now just Click on the Share button to share the greetings with your Family, Friends, and relatives. Thank You!</p>
Copyrights © 2018 | All Rights Reserved Powered by <a href="https://www.ripon.in">RipoN</a>
</span>
</center>
<br><br>
</div>
</div>
<center>
<a class="footerbtn" href="whatsapp://send?text=🔥 *Merry Christmas* 
🎁 *See!  Send XMas Gift for You* 🎁     
 👉👉###/?n=<?php echo str_replace(" ","%2B",$_GET["n"]); ?>"> <img width="25px" height="25px" src="https://goo.gl/AejrnN"/><b style="font-size: 20px;">Share on Whatsapp</b> <img width="25px" height="25px" src="https://goo.gl/AejrnN"/></a>
</center>

    </body>
</html> 

