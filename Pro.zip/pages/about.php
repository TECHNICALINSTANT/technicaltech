<!DOCTYPE html>
<html>
<head>
	<title>About us | Techripon.com </title>
	<meta property="og:type" content="page" />
    <meta property="og:title" content="About This Site" />
    <meta property="og:url" content="http://www.techripon.com/2019/">
    <meta property="og:description" content="www.techripon.com/2019/ is a site knows for making festival wishes greeting cards with names, like Happy new year wishing card, Diwali wishing card, Independent Day wishing card etc many more." />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" sizes="32x32" href="http://www.www.techripon.com/2019/img/wp.webp">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
<center><img src="https://goo.gl/xvjgXx" width="100%" height="8%" alt="A very merry Christmas and happy new year 2019"></center>
<div class="w3-bar">
  <button class="w3-bar-item w3-button w3-black" style="width:33.3%"><a href="about.php">About</a></button>
  <button class="w3-bar-item w3-button w3-teal" style="width:33.3%"><a href="###">Home</a></button>
  <button class="w3-bar-item w3-button w3-red" style="width:33.3%"><a href="tos.php">TOS</a></button>
</div>
<h2 style="text-align: center;">About This Site</h2>
<hr />
<p style="text-align: center;">www.techripon.com/2019/ is a site knows for making festival wishes greeting cards with names, like Happy new year wishing card, Diwali wishing card, Independent Day wishing card etc many more.</p>
<p style="text-align: center;">At this time we provide greetings card of Christmas, people can wish their family, friends, and relatives by sending a beautiful <strong>Merry Christmas</strong> Greetings with Name on Whatsapp, facebook, twitter and other social media.</p>
<hr />
<h2 style="text-align: center;">About Author</h2>
<p style="text-align: center;"><strong><a href="https://www.RipoN.in">RipoN</a></strong> is the Designer and the creator of this script. He is a Professional Blogger, YouTuber, SEO expert, and Web Developer since past 5 Years.</p>
<p style="text-align: center;"><span style="color: #3366ff;"><a style="color: #3366ff;" href="https://www.ripon.in/"><strong>Know more&gt;</strong></a></span></p>


<div class="w3-bar">
  <button class="w3-bar-item w3-button w3-black" style="width:33.3%"><a href="about.php">About</a></button>
  <button class="w3-bar-item w3-button w3-teal" style="width:33.3%"><a href="###">Home</a></button>
  <button class="w3-bar-item w3-button w3-red" style="width:33.3%"><a href="tos.php">TOS</a></button>
</div>
<center>
  Copyrights © 2018 | All Rights Reserved by <a href="https://www.ripon.in">RipoN</a>
</center>
</body>
</html>